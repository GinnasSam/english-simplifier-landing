# English Simplifier Pro

用 AI 实时简化复杂英文，边浏览网页边学英语。
Select any English text → get a simpler version, Chinese translation, and rich word cards on hover.

---

## 系统要求 / Requirements

- 电脑（Windows 或 Mac）
- **Google Chrome 浏览器**（必须），或 Microsoft Edge
- 一个 AI API Key（见下方获取教程）

---

## 第一步：安装插件 / Install

> 以下步骤只需做一次，约 3 分钟。

1. **下载安装包**：点击右侧 [Releases](../../releases) → 下载 `english-simplifier-pro-v3.zip`
2. **解压文件**：右键点击 zip 文件 → 「解压到此处」或「Extract Here」，得到一个文件夹
3. **打开 Chrome 扩展管理页面**：在 Chrome 地址栏输入以下地址并按回车：
   ```
   chrome://extensions/
   ```
4. **开启开发者模式**：页面**右上角**找到「开发者模式 / Developer mode」开关，点击打开（变为蓝色）
5. **加载插件**：点击左上角出现的「**加载已解压的扩展程序 / Load unpacked**」按钮
6. **选择文件夹**：在弹出的窗口中，找到并选择第 2 步解压出来的文件夹，点「选择文件夹」
7. **完成** ✅：插件已安装，Chrome 右上角工具栏会出现插件图标

> **图标没显示？** 点击 Chrome 右上角「拼图🧩」图标 → 找到 English Simplifier Pro → 点击图钉📌固定到工具栏

---

## 第二步：获取 API Key

插件需要 AI API Key 才能工作。选择以下任意一个平台：

### 推荐新手：Groq（有免费额度）
1. 打开网址：`console.groq.com`
2. 点「Sign Up」注册账号（支持 Google 账号直接登录）
3. 登录后进入「**API Keys**」菜单 → 点「**Create API Key**」
4. 给 Key 起个名字（随意），点「Submit」
5. **立即复制** Key（格式类似：`gsk_xxxxxxxxxxxxxxxx`）⚠️ 此页面只显示一次

### OpenAI
1. 打开网址：`platform.openai.com` → 注册并充值
2. 进入右上角头像 → 「API keys」→ 点「Create new secret key」
3. 复制 Key（格式：`sk-xxxxxxxxxxxx`）

### Claude（Anthropic）
1. 打开网址：`console.anthropic.com` → 注册并充值
2. 进入「API Keys」→ 点「Create Key」
3. 复制 Key（格式：`sk-ant-xxxxxxxxxxxx`）

---

## 第三步：填入 Key / Enter Your Key

1. 点击 Chrome 右上角的**插件图标**
2. 将复制好的 Key **粘贴**进输入框
3. 点击「**保存**」按钮
4. 点击弹窗底部「**学习记录**」→ 切换到「**设置**」标签页
5. 在「AI 提供商」中选择你使用的平台（Groq / OpenAI / Claude）
6. 完成 ✅ 现在可以开始使用了

---

## 使用方法 / How to Use

1. 点击插件图标，确认开关显示「**ON**」（绿色）
2. 选择简化强度：**Level 1**（初级，更简单）或 **Level 2**（中级）
3. 在任意网页上，用鼠标**选中一段英文文字**
4. 页面自动弹出简化结果（按句子编号逐句显示）
5. 点击「**中文**」查看中文翻译；点击「**原文对照**」查看原始英文
6. 鼠标**悬停弹窗中任意单词** → 弹出词卡（音标 + 词性 + 英文定义 + 中文）
7. 点击「**📊 学习记录**」查看你的阅读历史和统计数据

---

## 常见问题 / FAQ

**Q：选中英文后什么都没弹出？**
A：① 检查插件开关是否为「ON」② 检查 API Key 是否已填写并保存 ③ 刷新当前页面后重试

**Q：弹出「API Error」或报错？**
A：① 检查 Key 是否有效（可在对应平台控制台验证）② 检查「设置」页面选的 provider 和填入的 Key 是否一致（例如填的是 Groq Key，就要选 Groq）

**Q：能在手机上用吗？**
A：不能。此插件仅支持**电脑版** Chrome 或 Edge，不支持手机浏览器。

**Q：我的 API Key 安全吗？**
A：安全。Key 只保存在你自己浏览器本地（Chrome 存储），不会上传到任何服务器，插件作者也无法获取。

**Q：支持哪些网站？**
A：支持绝大多数网页，包括 Wikipedia、Reddit、X (Twitter)、YouTube 描述页、新闻网站等。少数使用严格安全策略的网站可能不支持。

**Q：Groq 的免费额度够用吗？**
A：日常英语阅读完全够用。Groq 免费层每天有大量请求额度，普通用户几乎不会用完。

---

## 功能列表 / Features

- 鼠标划选英文 → AI 实时简化，按句子编号显示
- **Level 1**（初级 A2）/ **Level 2**（中级 B1-B2）两档强度
- 简化版 / 原文对照 / 中文翻译 一键切换
- 单词悬停词卡：音标 + 词性 + 英文定义 + 中文释义
- 学习记录：自动保存，最多 500 条，按来源网站筛选
- 支持 Groq / OpenAI / Claude 三大 AI 平台

---

## 隐私说明 / Privacy

- API Key 仅保存在你自己的浏览器本地（Chrome 存储），不会上传
- 不收集任何使用数据，无追踪，无统计上报
- 你访问的网页内容不会被插件记录或上传

---

## 联系 / Contact

有问题或建议？欢迎联系：[请在此处填入你的微信号 / 邮箱]

---

## License

MIT
