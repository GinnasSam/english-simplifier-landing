# English Simplifier Pro

用 AI 实时简化复杂英文，边浏览网页边学英语。
Select any English text → get a simpler version, Chinese translation, and rich word cards on hover.

---

## 系统要求 / Requirements

- 电脑（Windows 或 Mac）
- **Google Chrome 浏览器**（必须），或 Microsoft Edge
- 一个 AI API Key（见下方获取教程）

---

## 第一步：安装插件 / Install

> 以下步骤只需做一次，约 3 分钟。

1. **下载安装包**：点击右侧 [Releases](../../releases) → 下载 `english-simplifier-pro-v3.zip`
2. **解压文件**：右键点击 zip 文件 → 「解压到此处」，得到一个文件夹
3. **打开 Chrome 扩展管理页面**：在地址栏输入以下地址并按回车：
   ```
   chrome://extensions/
   ```
4. **开启开发者模式**：页面**右上角**找到「开发者模式 / Developer mode」开关，点击打开（变蓝）
5. **加载插件**：点击左上角「**加载已解压的扩展程序 / Load unpacked**」按钮
6. **选择文件夹**：选择第 2 步解压出来的文件夹，点「选择文件夹」
7. **完成** ✅：Chrome 右上角工具栏出现插件图标

> **图标没显示？** 点击 Chrome 右上角「拼图🧩」图标 → 找到 English Simplifier Pro → 点击图钉📌固定

---

## 第二步：获取 API Key

选择以下任意一个平台，获取你自己的 API Key：

### OpenAI
1. 打开：`platform.openai.com` → 注册并充值
2. 右上角头像 → 「API keys」→ 「Create new secret key」
3. 复制 Key（格式：`sk-xxxxxxxxxxxx`）

### Claude（Anthropic）
1. 打开：`console.anthropic.com` → 注册并充值
2. 「API Keys」→ 「Create Key」
3. 复制 Key（格式：`sk-ant-xxxxxxxxxxxx`）

### DeepSeek（推荐国内用户）
1. 打开：`platform.deepseek.com` → 注册
2. 「API keys」→ 「创建 API key」
3. 复制 Key（格式：`sk-xxxxxxxxxxxx`）

### Kimi（月之暗面）
1. 打开：`platform.moonshot.cn` → 注册
2. 「API 密钥」→ 「新建 API Key」
3. 复制 Key（格式：`sk-xxxxxxxxxxxx`）

---

## 第三步：填入 Key / Enter Your Key

1. 点击 Chrome 右上角的**插件图标**
2. 将复制好的 Key **粘贴**进输入框，点「**保存**」
3. 点击弹窗底部「**学习记录**」→ 切换到「**设置**」标签页
4. 选择你使用的 AI 提供商（OpenAI / Claude / DeepSeek / Kimi）
5. 完成 ✅

---

## 使用方法 / How to Use

1. 点击插件图标，确认开关显示「**ON**」（绿色）
2. 选择简化强度：**Level 1**（初级）或 **Level 2**（中级）
3. 在任意网页上，用鼠标**选中一段英文**
4. 页面自动弹出简化结果（按句子编号显示）
5. 点「**中文**」查看翻译；点「**原文对照**」查看原文
6. 鼠标**悬停任意单词** → 弹出词卡（音标 + 词性 + 定义 + 中文）
7. 点「**📊 学习记录**」查看阅读历史和统计

---

## 常见问题 / FAQ

**Q：选中英文后什么都没弹出？**
A：① 确认插件开关为「ON」② 确认 API Key 已填写并保存 ③ 刷新页面后重试

**Q：提示 API 错误？**
A：① 检查 Key 是否有效 ② 确认设置页选的 provider 和填入的 Key 一致

**Q：能在手机上用吗？**
A：不能，仅支持**电脑版** Chrome 或 Edge。

**Q：Key 安全吗？**
A：Key 只保存在你自己的浏览器本地，不会上传到任何服务器。

---

## 功能列表 / Features

- 划选英文 → AI 实时简化，按句子编号显示
- Level 1（初级 A2）/ Level 2（中级 B1-B2）两档
- 简化版 / 原文对照 / 中文翻译 一键切换
- 单词悬停词卡：音标 + 词性 + 英文定义 + 中文
- 学习记录：自动保存最多 500 条，按来源筛选
- 支持 OpenAI / Claude / DeepSeek / Kimi

---

## 隐私 / Privacy

- Key 仅保存在本地浏览器，不会上传
- 无数据收集，无追踪，无统计上报

---

## 联系 / Contact

有问题或建议？关注抖音获取安装教程视频。

---

## License

MIT
