/**
 * utils/parser.js — Sentence splitting, context extraction, word span wrapping.
 */

function splitSentences(text) {
  if (!text || typeof text !== 'string') return [];
  // Temporarily replace known abbreviations to protect their periods
  const placeholder = '\x00';
  const abbrevs = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|e\.g|i\.e|U\.S|U\.K|approx|dept|est|fig|govt|min|max|no|vol|vs)\./gi;
  const protected_ = text.replace(abbrevs, (m) => m.slice(0, -1) + placeholder);
  const raw = protected_.match(/[^.!?]+[.!?]+[\s]*/g);
  if (!raw) return [text.trim()].filter(Boolean);
  return raw.map(s => s.replace(new RegExp(placeholder, 'g'), '.').trim()).filter(s => s.length > 0);
}

function extractContext(paragraphText, selectedText) {
  if (!paragraphText || !selectedText) return '';
  const sentences = splitSentences(paragraphText);
  if (sentences.length <= 1) return '';
  const key = selectedText.trim().slice(0, 40);
  const idx = sentences.findIndex(s => s.includes(key) || key.includes(s.slice(0, 30)));
  if (idx === -1) return '';
  const parts = [];
  if (idx > 0) parts.push(sentences[idx - 1]);
  if (idx < sentences.length - 1) parts.push(sentences[idx + 1]);
  return parts.join(' ');
}

/**
 * Wraps every English word in a hoverable span.
 * Non-word characters (punctuation, spaces) are preserved as-is.
 * @param {string} text
 * @returns {string} HTML string
 */
function wrapWordsInSpans(text) {
  // Escape HTML entities first
  const escaped = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Wrap each word (letters + apostrophes, min 2 chars) in a span
  return escaped.replace(/\b([a-zA-Z][a-zA-Z'-]*[a-zA-Z]|[a-zA-Z]{2,})\b/g, (match) => {
    const lookup = match.toLowerCase().replace(/'/g, '');
    return `<span class="es-word" data-word="${lookup}">${match}</span>`;
  });
}
