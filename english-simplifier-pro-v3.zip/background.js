/**
 * background.js — Service Worker
 * All network requests go through here to bypass page CSP restrictions.
 */

const GROQ_URL   = 'https://api.groq.com/openai/v1/chat/completions';
const OPENAI_URL = 'https://api.openai.com/v1/chat/completions';
const CLAUDE_URL = 'https://api.anthropic.com/v1/messages';
const DICT_URL   = 'https://api.dictionaryapi.dev/api/v2/entries/en/';

const LEVEL_PROMPTS = {
  1: `You simplify English for BEGINNER learners (A2 level).
- Use only very common everyday words
- Write short sentences (max 10 words each)
- Break long sentences into 2-3 short ones
- Keep ALL key facts
- Never add new information`,
  2: `You simplify English for INTERMEDIATE learners (B1-B2 level).
- Replace difficult words with clearer ones
- Shorten overly long sentences
- Keep all facts, details, and logical relationships
- Never add new information`
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'simplify':
      handleSimplify(message).then(sendResponse).catch(err => sendResponse({ error: err.message }));
      return true;
    case 'translate':
      handleTranslate(message).then(sendResponse).catch(err => sendResponse({ error: err.message }));
      return true;
    case 'defineWord':
      handleDefineWord(message).then(sendResponse).catch(err => sendResponse({ error: err.message }));
      return true;
    case 'translateWord':
      handleTranslateWord(message).then(sendResponse).catch(err => sendResponse({ error: err.message }));
      return true;
  }
});

async function handleSimplify({ text, context, level }) {
  const systemPrompt = LEVEL_PROMPTS[level] || LEVEL_PROMPTS[1];
  const userContent = context
    ? `Context (do NOT simplify):\n"${context}"\n\nText to simplify:\n"${text}"`
    : text;
  const result = await aiCall(
    systemPrompt + '\nOutput only simplified English. No quotes, no explanation.',
    userContent
  );
  return { result };
}

async function handleTranslate({ text }) {
  const result = await aiCall(
    '将以下英文准确翻译成自然流畅的中文。只输出翻译结果，不加任何解释。',
    text
  );
  return { result };
}

async function handleDefineWord({ word }) {
  try {
    const res = await fetch(DICT_URL + encodeURIComponent(word));
    if (res.ok) {
      const data = await res.json();
      const entry = data[0];

      const phonetic =
        entry?.phonetic ||
        (entry?.phonetics || []).find(p => p.text)?.text ||
        '';

      const meanings = (entry?.meanings || [])
        .slice(0, 3)
        .map(m => ({
          partOfSpeech: m.partOfSpeech || '',
          definitions: (m.definitions || [])
            .slice(0, 2)
            .map(d => d.definition)
            .filter(Boolean)
        }))
        .filter(m => m.definitions.length > 0);

      if (meanings.length > 0) {
        return { phonetic, meanings };
      }
    }
  } catch (e) {}

  // Fallback to AI
  try {
    const def = await aiCall(
      'Give a brief dictionary-style English definition for this word. One sentence only. No extra text.',
      word
    );
    return { phonetic: '', meanings: [{ partOfSpeech: '', definitions: [def] }] };
  } catch (e) {
    return { phonetic: '', meanings: [{ partOfSpeech: '', definitions: ['Definition not available.'] }] };
  }
}

async function handleTranslateWord({ word, meanings }) {
  const lines = meanings.map(m => {
    const pos = m.partOfSpeech ? `[${m.partOfSpeech}] ` : '';
    return pos + m.definitions.join('; ');
  }).join('\n');

  const prompt = `You are a dictionary translator. Translate these English definitions for the word "${word}" into concise Chinese.
Format: one line per meaning, use "；" to separate multiple Chinese synonyms.
Example: n. 搜索；查找；检索
Only output the translations, nothing else.`;

  const result = await aiCall(prompt, lines);
  return { result };
}

// ─── Provider router ───────────────────────────────────────────────────────

async function aiCall(systemPrompt, userContent) {
  const { provider } = await chrome.storage.local.get('provider');
  switch (provider || 'groq') {
    case 'openai': return openaiCall(systemPrompt, userContent);
    case 'claude': return claudeCall(systemPrompt, userContent);
    default:       return groqCall(systemPrompt, userContent);
  }
}

// ─── Groq ──────────────────────────────────────────────────────────────────

async function groqCall(systemPrompt, userContent) {
  const { groqApiKey } = await chrome.storage.local.get('groqApiKey');
  if (!groqApiKey) throw new Error('请先在插件设置中填入 Groq API Key');

  return fetchOpenAICompat(GROQ_URL, groqApiKey, 'llama-3.1-8b-instant', systemPrompt, userContent);
}

// ─── OpenAI ────────────────────────────────────────────────────────────────

async function openaiCall(systemPrompt, userContent) {
  const { openaiApiKey } = await chrome.storage.local.get('openaiApiKey');
  if (!openaiApiKey) throw new Error('请先在插件设置中填入 OpenAI API Key');

  return fetchOpenAICompat(OPENAI_URL, openaiApiKey, 'gpt-4o-mini', systemPrompt, userContent);
}

// ─── Shared OpenAI-compatible fetch ───────────────────────────────────────

async function fetchOpenAICompat(url, apiKey, model, systemPrompt, userContent) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: userContent  }
        ],
        max_tokens: 512,
        temperature: 0
      })
    });
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('请求超时，请稍后再试');
    throw e;
  } finally {
    clearTimeout(timeout);
  }

  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  return data?.choices?.[0]?.message?.content?.trim() || '';
}

// ─── Claude ────────────────────────────────────────────────────────────────

async function claudeCall(systemPrompt, userContent) {
  const { claudeApiKey } = await chrome.storage.local.get('claudeApiKey');
  if (!claudeApiKey) throw new Error('请先在插件设置中填入 Claude API Key');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  let res;
  try {
    res = await fetch(CLAUDE_URL, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': claudeApiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 512,
        system: systemPrompt,
        messages: [{ role: 'user', content: userContent }]
      })
    });
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('请求超时，请稍后再试');
    throw e;
  } finally {
    clearTimeout(timeout);
  }

  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  return data?.content?.[0]?.text?.trim() || '';
}
