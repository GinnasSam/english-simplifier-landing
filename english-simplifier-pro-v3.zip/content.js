/**
 * content.js v3 — Sentence display + rich word card on hover.
 */

// Subtle hover style for every word — no pre-marking
(function injectStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .es-word {
      cursor: help;
      border-radius: 2px;
      transition: background 0.1s;
    }
    .es-word:hover {
      background: rgba(255, 255, 255, 0.12);
    }
    @keyframes es-fade-in {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    @keyframes es-spin {
      to { transform: rotate(360deg); }
    }
    .es-enter {
      animation: es-fade-in 0.15s ease-out;
    }
    .es-spinner {
      display: inline-block;
      width: 11px;
      height: 11px;
      border: 2px solid #333;
      border-top-color: #2ecc71;
      border-radius: 50%;
      animation: es-spin 0.7s linear infinite;
      vertical-align: middle;
      margin-right: 7px;
      flex-shrink: 0;
    }
  `;
  (document.head || document.documentElement).appendChild(style);
})();

let mainTooltip    = null;
let wordTooltip    = null;
let wordHoverTimer = null;

// ─── Main selection handler ────────────────────────────────────────────────

document.addEventListener('mouseup', async (e) => {
  if (mainTooltip && mainTooltip.contains(e.target)) return;

  const selection    = window.getSelection();
  const selectedText = selection ? selection.toString().trim() : '';

  removeMainTooltip();

  if (!selectedText || selectedText.length < 5) return;
  if (!selection.rangeCount) return;

  const stored = await chrome.storage.local.get(['enabled', 'level']);
  if (!stored.enabled) return;

  const level = stored.level || 1;

  let rect;
  try { rect = selection.getRangeAt(0).getBoundingClientRect(); }
  catch (e) { return; }

  showMainTooltip('⏳ Simplifying...', rect);

  let context = '';
  try {
    const anchor    = selection.anchorNode;
    const parentEl  = anchor?.parentElement;
    const container =
      parentEl?.closest('article, [role="article"], main, section') ||
      parentEl?.closest('p, div, li, td') ||
      parentEl;
    if (container) {
      let rawText = container.innerText || '';
      if (rawText.length > 2000) {
        const pos   = rawText.indexOf(selectedText.slice(0, 30));
        const start = Math.max(0, pos - 1000);
        rawText = rawText.slice(start, start + 2000);
      }
      context = extractContext(rawText, selectedText);
    }
  } catch (e) {}

  try {
    const [simplified, chinese] = await Promise.all([
      simplifyText(selectedText, context, level),
      translateChinese(selectedText)
    ]);
    renderMainTooltip({
      original:   selectedText,
      simplified: simplified || selectedText,
      chinese:    chinese || '',
      level
    });
    saveSentence(selectedText, simplified || selectedText, chinese || '');
  } catch (err) {
    console.error('[ESv3]', err);
    updateMainTooltip('❌ ' + err.message);
  }
});

document.addEventListener('mousedown', (e) => {
  if (mainTooltip && !mainTooltip.contains(e.target)) removeMainTooltip();
});

// ─── Main tooltip render ───────────────────────────────────────────────────

function renderMainTooltip({ original, simplified, chinese, level }) {
  if (!mainTooltip) return;
  mainTooltip.innerHTML = '';
  mainTooltip.classList.remove('es-enter');
  void mainTooltip.offsetWidth; // reflow to restart animation
  mainTooltip.classList.add('es-enter');

  const badge = el('div', level === 1 ? '⭐ Level 1 — Easy' : '⭐⭐ Level 2 — Medium');
  badge.style.cssText = 'font-size:10px;color:#2ecc71;margin-bottom:10px;letter-spacing:0.5px;';

  const sentenceWrap = el('div');
  sentenceWrap.style.cssText = 'margin-bottom:12px;';
  renderSentenceBlocks(sentenceWrap, splitSentences(simplified), true);

  const btnRow = el('div');
  btnRow.style.cssText = 'display:flex;gap:6px;margin-top:4px;';

  const btnOriginal = makeBtn('原文对照');
  const btnChinese  = makeBtn('中文');
  let mode = 'simplified';

  btnOriginal.addEventListener('click', (e) => {
    e.stopPropagation();
    removeWordTooltip();
    if (mode === 'original') {
      mode = 'simplified';
      renderSentenceBlocks(sentenceWrap, splitSentences(simplified), true);
      btnOriginal.textContent = '原文对照';
      resetBtn(btnOriginal);
    } else {
      mode = 'original';
      renderSentenceBlocks(sentenceWrap, splitSentences(original), true);
      btnOriginal.textContent = '← 简化版';
      btnOriginal.style.color = '#f39c12';
      btnOriginal.style.borderColor = '#f39c12';
      resetBtn(btnChinese);
      btnChinese.textContent = '中文';
    }
  });

  btnChinese.addEventListener('click', (e) => {
    e.stopPropagation();
    removeWordTooltip();
    if (mode === 'chinese') {
      mode = 'simplified';
      renderSentenceBlocks(sentenceWrap, splitSentences(simplified), true);
      btnChinese.textContent = '中文';
      resetBtn(btnChinese);
    } else {
      mode = 'chinese';
      sentenceWrap.innerHTML = '';
      const para = el('div', chinese || '(翻译不可用)');
      para.style.cssText = 'font-size:13px;line-height:1.8;color:#eaeaea;';
      sentenceWrap.appendChild(para);
      btnChinese.textContent = '← English';
      btnChinese.style.color = '#f39c12';
      btnChinese.style.borderColor = '#f39c12';
      resetBtn(btnOriginal);
      btnOriginal.textContent = '原文对照';
    }
  });

  btnRow.appendChild(btnOriginal);
  btnRow.appendChild(btnChinese);

  mainTooltip.appendChild(badge);
  mainTooltip.appendChild(sentenceWrap);
  mainTooltip.appendChild(btnRow);

  mainTooltip.addEventListener('mouseover', handleWordHover);
  mainTooltip.addEventListener('mouseout',  handleWordOut);
}

// ─── Sentence blocks ───────────────────────────────────────────────────────

function renderSentenceBlocks(container, sentences, withWordHover) {
  container.innerHTML = '';
  sentences.forEach((sentence, i) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-bottom:6px;line-height:1.7;font-size:13px;';

    const num = el('span', (i + 1) + '.');
    num.style.cssText = 'color:#2ecc71;font-size:11px;min-width:16px;padding-top:2px;flex-shrink:0;';

    const text = document.createElement('span');
    text.style.cssText = 'flex:1;';
    if (withWordHover) {
      text.innerHTML = wrapWordsInSpans(sentence);
    } else {
      text.textContent = sentence;
    }

    row.appendChild(num);
    row.appendChild(text);
    container.appendChild(row);
  });
}

// ─── Word hover ────────────────────────────────────────────────────────────

function handleWordHover(e) {
  const target = e.target;
  if (!target.classList.contains('es-word')) return;

  clearTimeout(wordHoverTimer);
  removeWordTooltip();

  wordHoverTimer = setTimeout(async () => {
    const word = target.dataset.word;
    if (!word || word.length < 2) return;

    const rect = target.getBoundingClientRect();
    showWordTooltip(rect);
    renderWordCard({ word, phonetic: '', meanings: [], chinese: '加载中...' });

    try {
      const { phonetic, meanings } = await getWordDefinition(word);
      if (!wordTooltip) return;

      // Show English definitions immediately
      renderWordCard({ word, phonetic, meanings, chinese: '翻译中...' });

      // Fetch Chinese translation
      const chinese = await translateWordMeanings(word, meanings);
      if (!wordTooltip) return;

      renderWordCard({ word, phonetic, meanings, chinese });
      incrementWordCount();
    } catch (err) {
      if (wordTooltip) renderWordCard({ word, phonetic: '', meanings: [], chinese: '释义获取失败' });
    }
  }, 300);
}

function handleWordOut(e) {
  const target = e.target;
  if (!target.classList.contains('es-word')) return;
  // Don't close if mouse is moving into the word tooltip
  if (wordTooltip && wordTooltip.contains(e.relatedTarget)) return;
  clearTimeout(wordHoverTimer);
  removeWordTooltip();
}

// ─── Word card render ──────────────────────────────────────────────────────

function renderWordCard({ word, phonetic, meanings, chinese }) {
  if (!wordTooltip) return;
  wordTooltip.innerHTML = '';

  // ── Header: word + phonetic ──
  const header = document.createElement('div');
  header.style.cssText = `
    display: flex;
    align-items: baseline;
    gap: 8px;
    margin-bottom: 8px;
    padding-bottom: 8px;
    border-bottom: 1px solid #333;
  `;
  const wordEl = el('span', word);
  wordEl.style.cssText = 'font-size:15px;font-weight:700;color:#fff;';
  header.appendChild(wordEl);

  if (phonetic) {
    const phoneticEl = el('span', phonetic);
    phoneticEl.style.cssText = 'font-size:11px;color:#888;';
    header.appendChild(phoneticEl);
  }
  wordTooltip.appendChild(header);

  // ── Meanings ──
  if (meanings && meanings.length > 0) {
    meanings.forEach((m, i) => {
      const section = document.createElement('div');
      section.style.cssText = i < meanings.length - 1
        ? 'margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid #2a2a3a;'
        : 'margin-bottom:8px;';

      if (m.partOfSpeech) {
        const pos = el('div', m.partOfSpeech);
        pos.style.cssText = 'font-size:10px;color:#2ecc71;font-style:italic;font-weight:600;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px;';
        section.appendChild(pos);
      }

      m.definitions.forEach(def => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:5px;margin-bottom:2px;';

        const dot = el('span', '·');
        dot.style.cssText = 'color:#555;flex-shrink:0;';

        const defEl = el('span', def);
        defEl.style.cssText = 'font-size:12px;color:#ccc;line-height:1.5;';

        row.appendChild(dot);
        row.appendChild(defEl);
        section.appendChild(row);
      });

      wordTooltip.appendChild(section);
    });
  }

  // ── Chinese divider + translation ──
  const divider = el('div');
  divider.style.cssText = 'height:1px;background:#333;margin-bottom:8px;';
  wordTooltip.appendChild(divider);

  const zhEl = el('div', chinese);
  zhEl.style.cssText = 'font-size:13px;color:#f8c471;line-height:1.6;font-weight:500;';
  wordTooltip.appendChild(zhEl);
}

// ─── Tooltip helpers ───────────────────────────────────────────────────────

function showMainTooltip(text, rect) {
  mainTooltip = document.createElement('div');
  mainTooltip.id = 'es-main-tooltip';

  // Spinner loading state
  const spinnerEl = document.createElement('span');
  spinnerEl.className = 'es-spinner';
  const labelEl = document.createElement('span');
  labelEl.textContent = 'Simplifying...';
  labelEl.style.cssText = 'font-size:12px;color:#888;vertical-align:middle;';
  const loadingWrap = document.createElement('div');
  loadingWrap.style.cssText = 'display:flex;align-items:center;';
  loadingWrap.appendChild(spinnerEl);
  loadingWrap.appendChild(labelEl);
  mainTooltip.appendChild(loadingWrap);

  const spaceBelow = window.innerHeight - rect.bottom;
  const top = spaceBelow > 180 ? rect.bottom + 8 : rect.top - 8;

  Object.assign(mainTooltip.style, {
    position:     'fixed',
    top:          top + 'px',
    left:         Math.min(Math.max(8, rect.left), window.innerWidth - 450) + 'px',
    maxWidth:     '440px',
    background:   '#12122a',
    color:        '#eaeaea',
    fontSize:     '13px',
    padding:      '14px 16px',
    borderRadius: '10px',
    boxShadow:    '0 6px 28px rgba(0,0,0,0.5)',
    zIndex:       '2147483646',
    wordBreak:    'break-word',
    border:       '1px solid #2ecc71',
    transform:    spaceBelow > 180 ? 'none' : 'translateY(-100%)'
  });

  mainTooltip.classList.add('es-enter');
  document.body.appendChild(mainTooltip);
}

function updateMainTooltip(text) {
  if (mainTooltip) mainTooltip.textContent = text;
}

function removeMainTooltip() {
  removeWordTooltip();
  if (mainTooltip) { mainTooltip.remove(); mainTooltip = null; }
}

function showWordTooltip(rect) {
  removeWordTooltip();
  wordTooltip = document.createElement('div');
  wordTooltip.id = 'es-word-tooltip';

  const spaceBelow = window.innerHeight - rect.bottom;
  const top = spaceBelow > 120 ? rect.bottom + 6 : rect.top - 6;

  Object.assign(wordTooltip.style, {
    position:     'fixed',
    top:          top + 'px',
    left:         Math.min(Math.max(8, rect.left), window.innerWidth - 360) + 'px',
    width:        '340px',
    background:   '#1a1a2e',
    color:        '#f0f0f0',
    fontSize:     '12px',
    padding:      '12px 14px',
    borderRadius: '8px',
    boxShadow:    '0 4px 20px rgba(0,0,0,0.5)',
    zIndex:       '2147483647',
    border:       '1px solid #3a3a5a',
    wordBreak:    'break-word',
    lineHeight:   '1.6',
    transform:    spaceBelow > 120 ? 'none' : 'translateY(-100%)'
  });

  wordTooltip.classList.add('es-enter');
  wordTooltip.addEventListener('mouseleave', () => removeWordTooltip());
  document.body.appendChild(wordTooltip);
}

function updateWordTooltip(text) {
  if (wordTooltip) wordTooltip.textContent = text;
}

function removeWordTooltip() {
  clearTimeout(wordHoverTimer);
  if (wordTooltip) { wordTooltip.remove(); wordTooltip = null; }
}

// ─── Utilities ─────────────────────────────────────────────────────────────

function el(tag, text = '') {
  const e = document.createElement(tag);
  if (text) e.textContent = text;
  return e;
}

function makeBtn(label) {
  const btn = document.createElement('button');
  btn.textContent = label;
  btn.style.cssText = `
    background: transparent;
    border: 1px solid #2ecc71;
    color: #2ecc71;
    border-radius: 4px;
    padding: 3px 10px;
    font-size: 11px;
    cursor: pointer;
  `;
  return btn;
}

function resetBtn(btn) {
  btn.style.color       = '#2ecc71';
  btn.style.borderColor = '#2ecc71';
}

// ─── Data collection ───────────────────────────────────────────────────────

function saveSentence(original, simplified, chinese) {
  const today = new Date().toISOString().slice(0, 10);
  const domain = location.hostname.replace(/^www\./, '');
  const entry = { original, simplified, chinese, date: today, domain };

  chrome.storage.local.get(['savedSentences', 'stats'], (data) => {
    const sentences = data.savedSentences || [];
    sentences.unshift(entry);

    // Update stats
    const stats = data.stats || { totalSentences: 0, totalWords: 0 };
    stats.totalSentences = (stats.totalSentences || 0) + 1;

    chrome.storage.local.set({ savedSentences: sentences, stats });
  });
}

function incrementWordCount() {
  chrome.storage.local.get('stats', (data) => {
    const stats = data.stats || { totalSentences: 0, totalWords: 0 };
    stats.totalWords = (stats.totalWords || 0) + 1;
    chrome.storage.local.set({ stats });
  });
}
