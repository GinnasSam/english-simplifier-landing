/**
 * services/ai.js — Proxy all API calls through background.js to bypass page CSP.
 */

function sendToBackground(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response) {
        reject(new Error('No response from background'));
        return;
      }
      if (response.error) {
        reject(new Error(response.error));
        return;
      }
      resolve(response);
    });
  });
}

async function simplifyText(text, context, level) {
  const { result } = await sendToBackground({ action: 'simplify', text, context, level });
  return result;
}

async function translateChinese(text) {
  const { result } = await sendToBackground({ action: 'translate', text });
  return result;
}

async function getWordDefinition(word) {
  const { phonetic, meanings } = await sendToBackground({ action: 'defineWord', word });
  return { phonetic, meanings };
}

async function translateWordMeanings(word, meanings) {
  const { result } = await sendToBackground({ action: 'translateWord', word, meanings });
  return result;
}
