/**
 * popup.js — ON/OFF toggle + level selector + API key management.
 */

const toggle          = document.getElementById('toggle');
const statusLabel     = document.getElementById('status-label');
const hintText        = document.getElementById('hint-text');
const levelBtns       = document.querySelectorAll('.level-btn');
const keyInput        = document.getElementById('key-input');
const keySave         = document.getElementById('key-save');
const keyStatus       = document.getElementById('key-status');
const openOptions     = document.getElementById('open-options');

const PROVIDER_PLACEHOLDERS = {
  groq:     '粘贴 API Key',
  openai:   '粘贴 API Key',
  claude:   '粘贴 API Key',
  deepseek: '粘贴 API Key',
  kimi:     '粘贴 API Key'
};

const PROVIDER_KEY_FIELDS = {
  groq:     'groqApiKey',
  openai:   'openaiApiKey',
  claude:   'claudeApiKey',
  deepseek: 'deepseekApiKey',
  kimi:     'kimiApiKey'
};

const PROVIDER_LABELS = {
  groq:     'Groq',
  openai:   'OpenAI',
  claude:   'Claude',
  deepseek: 'DeepSeek',
  kimi:     'Kimi'
};

let currentProvider = 'groq';

// Load saved state
chrome.storage.local.get(['enabled', 'level', 'provider', 'groqApiKey', 'openaiApiKey', 'claudeApiKey', 'deepseekApiKey', 'kimiApiKey'], (result) => {
  const enabled = !!result.enabled;
  const level   = result.level || 1;
  currentProvider = result.provider || 'groq';

  toggle.checked = enabled;
  updateToggleUI(enabled);
  setActiveLevel(level);
  keyInput.placeholder = PROVIDER_PLACEHOLDERS[currentProvider] || '';
  document.getElementById('provider-label').textContent = PROVIDER_LABELS[currentProvider] || currentProvider;
  updateKeyStatus(result[PROVIDER_KEY_FIELDS[currentProvider]]);
});

// Toggle ON/OFF
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ enabled }, () => updateToggleUI(enabled));
});

// Level buttons
levelBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const level = parseInt(btn.dataset.level);
    chrome.storage.local.set({ level });
    setActiveLevel(level);
  });
});

// Save API key
keySave.addEventListener('click', () => {
  const key = keyInput.value.trim();
  if (!key) return;
  const field = PROVIDER_KEY_FIELDS[currentProvider];
  chrome.storage.local.set({ [field]: key }, () => {
    keyInput.value = '';
    updateKeyStatus(key);
  });
});

// Open options page
openOptions.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

function updateToggleUI(enabled) {
  statusLabel.textContent = enabled ? 'ON' : 'OFF';
  statusLabel.className   = 'toggle-label ' + (enabled ? 'on' : 'off');
  hintText.textContent    = enabled
    ? 'Select any English text to simplify it.'
    : 'Turn ON, then select any English text.';
}

function setActiveLevel(level) {
  levelBtns.forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.level) === level);
  });
}

function updateKeyStatus(key) {
  if (key) {
    keyStatus.textContent = '✅ 已设置';
    keyStatus.className   = 'key-status set';
  } else {
    keyStatus.textContent = '⚠️ 未设置';
    keyStatus.className   = 'key-status unset';
  }
}
