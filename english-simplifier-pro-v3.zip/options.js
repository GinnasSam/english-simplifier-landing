/**
 * options.js — 学习记录管理页面逻辑
 */

// ─── Tab switching ─────────────────────────────────────────────────────────

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('panel-' + tab.dataset.tab).classList.add('active');
  });
});

// ─── Load all data on page open ───────────────────────────────────────────

chrome.storage.local.get(['stats', 'savedSentences', 'groqApiKey', 'openaiApiKey', 'claudeApiKey', 'level', 'provider'], (data) => {
  renderOverview(data.stats || {});
  renderSentences(data.savedSentences || []);
  renderSettings(data.groqApiKey, data.openaiApiKey, data.claudeApiKey, data.level || 1, data.provider || 'groq');
});

// ─── 总览 ─────────────────────────────────────────────────────────────────

function renderOverview(stats) {
  document.getElementById('stat-sentences').textContent = stats.totalSentences || 0;
  document.getElementById('stat-words').textContent     = stats.totalWords || 0;

  // Count unique days from saved sentences
  chrome.storage.local.get('savedSentences', (data) => {
    const sentences = data.savedSentences || [];
    const days = new Set(sentences.map(s => s.date)).size;
    document.getElementById('stat-days').textContent = days;
  });
}

// ─── 难句集 ───────────────────────────────────────────────────────────────

let allSentences = [];

function renderSentences(sentences) {
  allSentences = sentences;

  // Populate domain filter
  const domains = [...new Set(sentences.map(s => s.domain).filter(Boolean))].sort();
  const select = document.getElementById('domain-filter');
  select.innerHTML = '<option value="">全部来源</option>';
  domains.forEach(d => {
    const opt = document.createElement('option');
    opt.value = d;
    opt.textContent = d;
    select.appendChild(opt);
  });

  filterAndRender();
}

function filterAndRender() {
  const query  = document.getElementById('search-input').value.trim().toLowerCase();
  const domain = document.getElementById('domain-filter').value;

  const filtered = allSentences.filter(s => {
    const matchDomain = !domain || s.domain === domain;
    const matchQuery  = !query ||
      s.original.toLowerCase().includes(query) ||
      s.simplified.toLowerCase().includes(query) ||
      (s.chinese || '').includes(query);
    return matchDomain && matchQuery;
  });

  const list = document.getElementById('sentence-list');
  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-state">没有找到匹配的句子</div>';
    return;
  }

  list.innerHTML = '';
  filtered.forEach(s => {
    const card = document.createElement('div');
    card.className = 'sentence-card';
    card.innerHTML = `
      <div class="meta">
        <span>${s.date || ''}</span>
        <span>${s.domain || ''}</span>
      </div>
      <div class="original"><span class="label-tag">原文</span>${escapeHtml(s.original)}</div>
      <div class="simplified"><span class="label-tag">简化</span>${escapeHtml(s.simplified)}</div>
      ${s.chinese ? `<div class="chinese"><span class="label-tag">中文</span>${escapeHtml(s.chinese)}</div>` : ''}
    `;
    list.appendChild(card);
  });
}

document.getElementById('search-input').addEventListener('input', filterAndRender);
document.getElementById('domain-filter').addEventListener('change', filterAndRender);

document.getElementById('clear-all').addEventListener('click', () => {
  if (!confirm('确定清空所有难句记录？此操作不可撤销。')) return;
  chrome.storage.local.remove('savedSentences', () => {
    allSentences = [];
    filterAndRender();
    // Reset day count in overview
    document.getElementById('stat-days').textContent = 0;
  });
});

// ─── 设置 ─────────────────────────────────────────────────────────────────

function renderSettings(groqApiKey, openaiApiKey, claudeApiKey, level, provider) {
  setKeyPlaceholder('groq-key-input',   groqApiKey,   'gsk_...');
  setKeyPlaceholder('openai-key-input', openaiApiKey, 'sk-...');
  setKeyPlaceholder('claude-key-input', claudeApiKey, 'sk-ant-...');

  document.querySelectorAll('.level-opt:not(.provider-opt)').forEach(opt => {
    opt.classList.toggle('active', parseInt(opt.dataset.level) === level);
  });

  document.querySelectorAll('.provider-opt').forEach(opt => {
    opt.classList.toggle('active', opt.dataset.provider === provider);
  });
}

function setKeyPlaceholder(inputId, key, emptyPlaceholder) {
  const input = document.getElementById(inputId);
  if (input) input.placeholder = key ? '••••••••（已设置，重新输入可更新）' : emptyPlaceholder;
}

function makeKeySaveHandler(inputId, storageField, msgId) {
  document.getElementById(inputId.replace('input', 'save')).addEventListener('click', () => {
    const key = document.getElementById(inputId).value.trim();
    if (!key) return;
    chrome.storage.local.set({ [storageField]: key }, () => {
      const input = document.getElementById(inputId);
      input.value = '';
      input.placeholder = '••••••••（已设置，重新输入可更新）';
      const msg = document.getElementById(msgId);
      msg.classList.add('show');
      setTimeout(() => msg.classList.remove('show'), 2000);
    });
  });
}

makeKeySaveHandler('groq-key-input',   'groqApiKey',   'groq-save-msg');
makeKeySaveHandler('openai-key-input', 'openaiApiKey', 'openai-save-msg');
makeKeySaveHandler('claude-key-input', 'claudeApiKey', 'claude-save-msg');

document.querySelectorAll('.level-opt:not(.provider-opt)').forEach(opt => {
  opt.addEventListener('click', () => {
    const level = parseInt(opt.dataset.level);
    chrome.storage.local.set({ level });
    document.querySelectorAll('.level-opt:not(.provider-opt)').forEach(o => {
      o.classList.toggle('active', parseInt(o.dataset.level) === level);
    });
  });
});

document.querySelectorAll('.provider-opt').forEach(opt => {
  opt.addEventListener('click', () => {
    const provider = opt.dataset.provider;
    chrome.storage.local.set({ provider });
    document.querySelectorAll('.provider-opt').forEach(o => {
      o.classList.toggle('active', o.dataset.provider === provider);
    });
  });
});

// ─── Util ─────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
